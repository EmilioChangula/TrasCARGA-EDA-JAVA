package tad;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Iterator;
import java.util.NoSuchElementException;
import org.junit.jupiter.api.Test;

/**
 * Testes do TAD Deque (DequeArray): inserção/remoção nas duas extremidades,
 * estruturas vazias e de um único elemento, ordem e ausência de perdas.
 */
public class DequeArrayTest {

    @Test
    public void inserirNosDoisFins_mantemAOrdem() {
        Deque<String> d = new DequeArray<>();
        d.addLast("b");
        d.addLast("c");
        d.addFirst("a");

        assertEquals(3, d.size());
        assertFalse(d.isEmpty());
        assertEquals("a", d.get(0));
        assertEquals("b", d.get(1));
        assertEquals("c", d.get(2));
        assertEquals("a", d.peekFirst());
        assertEquals("c", d.peekLast());
    }

    @Test
    public void removerNosDoisFins_devolvePorOrdem() {
        Deque<Integer> d = new DequeArray<>();
        for (int i = 1; i <= 5; i++) {
            d.addLast(i);
        }

        assertEquals(1, d.removeFirst());
        assertEquals(5, d.removeLast());
        assertEquals(3, d.size());
        assertEquals(2, d.peekFirst());
        assertEquals(4, d.peekLast());
        assertEquals(2, d.get(0));
        assertEquals(3, d.get(1));
        assertEquals(4, d.get(2));
    }

    @Test
    public void estruturaVazia_operacoesDevolvemNullEIndiceInvalido() {
        Deque<String> d = new DequeArray<>();

        assertTrue(d.isEmpty());
        assertEquals(0, d.size());
        assertNull(d.removeFirst());
        assertNull(d.removeLast());
        assertNull(d.peekFirst());
        assertNull(d.peekLast());
        assertThrows(IndexOutOfBoundsException.class, () -> d.get(0));

        d.clear(); // idempotente
        assertTrue(d.isEmpty());
        assertEquals(0, d.size());
    }

    @Test
    public void umElemento_permiteRemoverPelosDoisLados() {
        DequeArray<String> d = new DequeArray<>();

        d.addFirst("unico");
        assertEquals("unico", d.removeLast());
        assertTrue(d.isEmpty());

        d.addLast("unico");
        assertEquals("unico", d.removeFirst());
        assertTrue(d.isEmpty());
        assertNull(d.peekFirst());
    }

    @Test
    public void ultrapassarACapacidade_naoPerdeNemRepeteElementos() {
        DequeArray<Integer> d = new DequeArray<>();
        int n = 1000; // força várias duplicações (capacidade inicial 10)

        for (int i = 0; i < n; i++) {
            d.addLast(i);
        }
        for (int i = 0; i < 300; i++) {
            d.removeFirst();          // remove 0..299
        }
        for (int i = 0; i < 300; i++) {
            d.addFirst(-1 - i);       // prepõe -1, -2, ... -300
        }

        assertEquals(n, d.size());

        // ordem esperada: -300..-1 e depois 300..999
        int esperado = -300;
        for (int i = 0; i < 300; i++) {
            assertEquals(esperado++, d.get(i));
        }
        for (int i = 300; i < n; i++) {
            assertEquals(i, d.get(i));
        }
    }

    @Test
    public void darAVoltaAoCircular_misturarInsercoesERemoções() {
        DequeArray<Integer> d = new DequeArray<>();
        int inseridos = 0;
        int removidos = 0;

        // 400 operações: enche/remove sem parar, fazendo o índice "inicio"
        // rodar várias vezes pelo array circular (capacidade inicial 10)
        for (int i = 0; i < 400; i++) {
            d.addLast(inseridos++);
            if (d.size() > 7) {
                assertEquals(removidos++, d.removeFirst());
            }
        }

        // toda a ordem lógica ficou intacta: removidos..inseridos-1
        assertEquals(inseridos - removidos, d.size());
        for (int i = 0; i < d.size(); i++) {
            assertEquals(removidos + i, d.get(i));
        }

        // esvazia totalmente pelas duas extremidades
        while (d.size() > 1) {
            assertEquals(removidos++, d.removeFirst());
        }
        assertEquals(removidos, d.removeLast());
        assertTrue(d.isEmpty());
        assertNull(d.removeFirst());
    }

    @Test
    public void iterador_percorreNaOrdemLogicaEAoFimLancaNoSuchElement() {
        DequeArray<String> d = new DequeArray<>();
        d.addLast("x");
        d.addLast("y");
        d.addFirst("w");

        StringBuilder sb = new StringBuilder();
        for (String s : d) {
            sb.append(s);
        }
        assertEquals("wxy", sb.toString());

        Iterator<String> it = d.iterator();
        it.next();
        it.next();
        it.next();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    public void duplicar_preservaOrdemETamanho() {
        DequeArray<Integer> d = new DequeArray<>();
        d.addLast(1);
        d.addLast(2);
        d.addFirst(0);

        d.duplicar(); // cresce mantendo a ordem lógica

        assertEquals(3, d.size());
        assertEquals(0, d.get(0));
        assertEquals(1, d.get(1));
        assertEquals(2, d.get(2));

        d.addLast(3);
        assertEquals(4, d.size());
        assertEquals(3, d.get(3));
    }

    @Test
    public void toString_reflectAOrdemDosElementos() {
        DequeArray<Integer> d = new DequeArray<>();
        d.addLast(2);
        d.addFirst(1);
        assertEquals("[1, 2]", d.toString());
    }
}
