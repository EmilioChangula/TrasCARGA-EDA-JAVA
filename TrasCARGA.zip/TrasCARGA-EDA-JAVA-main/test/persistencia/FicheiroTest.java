package persistencia;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tad.DequeArray;
import util.FicheirosDeTeste;

/**
 * Persistência: serialização/desserialização do Deque em ficheiros de objectos
 * e comportamento perante ficheiro inexistente.
 */
public class FicheiroTest {

    private static final String FICHEIRO = "teste-ficheiro.dat";

    @BeforeEach
    public void preparar() {
        FicheirosDeTeste.limpar();
        FicheirosDeTeste.apagar(FICHEIRO);
    }

    @AfterEach
    public void terminar() {
        FicheirosDeTeste.limpar();
        FicheirosDeTeste.apagar(FICHEIRO);
    }

    @Test
    public void guardarECarregar_preservaElementosEOrdem() {
        DequeArray<String> original = new DequeArray<>();
        original.addLast("um");
        original.addFirst("zero");
        original.addLast("dois");

        Ficheiro.guardar(FICHEIRO, original);
        assertTrue(new File(FICHEIRO).exists(), "o ficheiro deve ser criado automaticamente");

        DequeArray<String> lido = Ficheiro.carregar(FICHEIRO);
        assertEquals(3, lido.size());
        assertEquals("zero", lido.get(0));
        assertEquals("um", lido.get(1));
        assertEquals("dois", lido.get(2));
        assertEquals(original.toString(), lido.toString());
    }

    @Test
    public void carregar_ficheiroInexistente_devolveDequeVazio() {
        DequeArray<String> lido = Ficheiro.carregar("nao-existe.dat");
        assertNotNull(lido);
        assertTrue(lido.isEmpty());
        assertEquals(0, lido.size());
    }
}
