package controller;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.Camiao;
import model.Carrinha;
import model.Proprietario;
import model.Veiculo;
import tad.DequeArray;
import util.FicheirosDeTeste;

/**
 * Requisitos 2, 3, 4, 5 e 6: cadastro de veículos (camiões e carrinhas),
 * associação obrigatória ao proprietário, actualização, listagem ordenada
 * por capacidade e persistência/relinkagem.
 */
public class VeiculoControllerTest {

    private ProprietarioController pc;
    private VeiculoController vc;

    @BeforeEach
    public void preparar() {
        FicheirosDeTeste.limpar();
        pc = new ProprietarioController();
        pc.cadastrar("Dono Um", "840000001", "BI-V1");
        vc = new VeiculoController();
    }

    private Proprietario dono(String documento) {
        return pc.buscarPorDocumento(documento);
    }

    private static List<String> matriculas(DequeArray<Veiculo> vs) {
        List<String> r = new ArrayList<>();
        for (Veiculo v : vs) {
            r.add(v.getMatricula());
        }
        return r;
    }

    @Test
    public void cadastrarCamiao_guardaComProprietarioAssociado() {
        assertTrue(vc.cadastrarCamiao("CH-001", "ABC-123", "Mercedes", "Actros", 20, dono("BI-V1")));

        Veiculo v = vc.buscarPorMatricula("ABC-123");
        assertNotNull(v);
        assertInstanceOf(Camiao.class, v);
        assertEquals("CH-001", v.getNrChassi());
        assertEquals("Mercedes", v.getMarca());
        assertEquals("Actros", v.getModelo());
        assertEquals(20, v.getCapacidade());
        // requisito 3: veículo associado a um único proprietário
        assertSame(dono("BI-V1"), v.getProprietario());
        assertEquals("Dono Um", v.getProprietario().getNome());
    }

    @Test
    public void cadastrarCarrinha_guardaComoCarrinha() {
        assertTrue(vc.cadastrarCarrinha("CH-002", "XYZ-777", "Ford", "Transit", 1.5, dono("BI-V1")));

        Veiculo v = vc.buscarPorMatricula("XYZ-777");
        assertInstanceOf(Carrinha.class, v);
        assertEquals("Carrinha", v.getTipo());
        assertSame(dono("BI-V1"), v.getProprietario());
    }

    @Test
    public void cadastro_rejeitaSemProprietarioDuplicadosEVazios() {
        assertTrue(vc.cadastrarCamiao("CH-001", "ABC-123", "Mercedes", "Actros", 20, dono("BI-V1")));

        // requisito 3: sem proprietário válido não regista
        assertFalse(vc.cadastrarCamiao("CH-003", "ABC-999", "Iveco", "Daily", 5, null));

        // matrícula e chassi únicos
        assertFalse(vc.cadastrarCarrinha("CH-004", "ABC-123", "Ford", "Transit", 1.5, dono("BI-V1")));
        assertFalse(vc.cadastrarCamiao("CH-001", "ABC-999", "Iveco", "Daily", 5, dono("BI-V1")));

        // capacidade obrigatória e positiva (em toneladas)
        assertFalse(vc.cadastrarCamiao("CH-005", "ABC-999", "Iveco", "Daily", 0, dono("BI-V1")));
        assertFalse(vc.cadastrarCamiao("CH-005", "ABC-999", "Iveco", "Daily", -3, dono("BI-V1")));

        // dados obrigatórios
        assertFalse(vc.cadastrarCamiao(" ", "ABC-999", "Iveco", "Daily", 5, dono("BI-V1")));
        assertFalse(vc.cadastrarCamiao("CH-005", " ", "Iveco", "Daily", 5, dono("BI-V1")));
        assertFalse(vc.cadastrarCamiao("CH-005", "ABC-999", "", "Daily", 5, dono("BI-V1")));
        assertFalse(vc.cadastrarCamiao("CH-005", "ABC-999", "Iveco", null, 5, dono("BI-V1")));

        assertEquals(1, vc.listarTodos().size());
    }

    @Test
    public void listarCamioes_ordenaPorCapacidadeCrescenteESoCamoioes() {
        assertTrue(vc.cadastrarCamiao("CH-10", "M-15", "Scania", "R500", 15, dono("BI-V1")));
        assertTrue(vc.cadastrarCamiao("CH-11", "M-03", "Volvo", "FH", 3, dono("BI-V1")));
        assertTrue(vc.cadastrarCamiao("CH-12", "M-08", "Mercedes", "Actros", 8, dono("BI-V1")));
        assertTrue(vc.cadastrarCarrinha("CH-13", "C-04", "Ford", "Transit", 4, dono("BI-V1")));

        DequeArray<Veiculo> camioes = vc.listarCamioes();

        // requisito 5: só camiões, por ordem crescente de capacidade
        assertEquals(List.of("M-03", "M-08", "M-15"), matriculas(camioes));
        for (Veiculo v : camioes) {
            assertInstanceOf(Camiao.class, v);
        }
    }

    @Test
    public void listarCarrinhas_ordenaPorCapacidadeCrescenteESoCarrinhas() {
        assertTrue(vc.cadastrarCarrinha("CH-20", "C-09", "Mercedes", "Vito", 9, dono("BI-V1")));
        assertTrue(vc.cadastrarCarrinha("CH-21", "C-01", "Fiat", "Ducato", 1, dono("BI-V1")));
        assertTrue(vc.cadastrarCarrinha("CH-22", "C-05", "Ford", "Transit", 5, dono("BI-V1")));
        assertTrue(vc.cadastrarCamiao("CH-23", "M-30", "Scania", "R500", 30, dono("BI-V1")));

        DequeArray<Veiculo> carrinhas = vc.listarCarrinhas();

        // requisito 6: só carrinhas, por ordem crescente de capacidade
        assertEquals(List.of("C-01", "C-05", "C-09"), matriculas(carrinhas));
        for (Veiculo v : carrinhas) {
            assertInstanceOf(Carrinha.class, v);
        }
    }

    @Test
    public void actualizar_alteraDadosMasNaoAChaveNemAProprietario() {
        assertTrue(vc.cadastrarCamiao("CH-001", "ABC-123", "Mercedes", "Actros", 20, dono("BI-V1")));

        assertTrue(vc.actualizar("CH-001", "ABC-123", "Scania", "R500", 25));

        Veiculo v = vc.buscarPorMatricula("ABC-123");
        assertEquals("Scania", v.getMarca());
        assertEquals("R500", v.getModelo());
        assertEquals(25, v.getCapacidade());
        assertEquals("CH-001", v.getNrChassi());
        assertSame(dono("BI-V1"), v.getProprietario());

        // matrícula inexistente não actualiza
        assertFalse(vc.actualizar("CH-999", "NAO-EXISTE", "Marca", "Modelo", 10));
        // chassi que já pertence a outro veículo é rejeitado
        assertTrue(vc.cadastrarCamiao("CH-002", "XYZ-777", "Ford", "Transit", 1.5, dono("BI-V1")));
        assertFalse(vc.actualizar("CH-002", "ABC-123", "Ford", "Transit", 1.5));
        // capacidade inválida
        assertFalse(vc.actualizar("CH-001", "ABC-123", "Scania", "R500", 0));
    }

    @Test
    public void remover_apagaApenasOAlvo() {
        assertTrue(vc.cadastrarCamiao("CH-001", "ABC-123", "Mercedes", "Actros", 20, dono("BI-V1")));
        assertTrue(vc.cadastrarCarrinha("CH-002", "XYZ-777", "Ford", "Transit", 1.5, dono("BI-V1")));

        assertTrue(vc.remover("ABC-123"));
        assertNull(vc.buscarPorMatricula("ABC-123"));
        assertNotNull(vc.buscarPorMatricula("XYZ-777"));
        assertFalse(vc.remover("ABC-123"));
    }

    @Test
    public void temProprietario_detectaVeiculosAssociados() {
        assertFalse(vc.temProprietario("BI-V1"));
        assertTrue(vc.cadastrarCamiao("CH-001", "ABC-123", "Mercedes", "Actros", 20, dono("BI-V1")));
        assertTrue(vc.temProprietario("BI-V1"));
        assertFalse(vc.temProprietario("BI-OUTRO"));
    }

    @Test
    public void persistencia_relinkarReconstroiAsReferenciasAposReiniciar() {
        assertTrue(vc.cadastrarCamiao("CH-001", "ABC-123", "Mercedes", "Actros", 20, dono("BI-V1")));

        // reinício: cada ficheiro é lido de forma independente (cópias distintas)
        ProprietarioController pc2 = new ProprietarioController();
        VeiculoController vc2 = new VeiculoController();
        Veiculo v = vc2.buscarPorMatricula("ABC-123");
        assertNotNull(v);
        assertNotSame(pc2.buscarPorDocumento("BI-V1"), v.getProprietario());

        // relinkar liga o veículo ao proprietário canónico do ficheiro principal
        vc2.relinkar(pc2);
        assertSame(pc2.buscarPorDocumento("BI-V1"), vc2.buscarPorMatricula("ABC-123").getProprietario());
    }
}
