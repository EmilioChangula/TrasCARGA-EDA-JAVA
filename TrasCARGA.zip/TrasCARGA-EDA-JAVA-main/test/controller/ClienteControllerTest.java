package controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.Cliente;
import util.FicheirosDeTeste;

/**
 * Requisito 7: cadastro de clientes (nome, contacto, localização),
 * com impedimento de documentos duplicados e persistência.
 */
public class ClienteControllerTest {

    private ClienteController cc;

    @BeforeEach
    public void preparar() {
        FicheirosDeTeste.limpar();
        cc = new ClienteController();
    }

    @Test
    public void cadastrar_guardaComTodosOsCampos() {
        assertTrue(cc.cadastrar("CLI-001", "Marta Silva", "842222222", "Beira"));

        Cliente c = cc.buscarPorDocumento("CLI-001");
        assertNotNull(c);
        assertEquals("Marta Silva", c.getNome());
        assertEquals("842222222", c.getContacto());
        assertEquals("Beira", c.getLocalizacao());
        assertEquals(1, cc.listar().size());
    }

    @Test
    public void cadastrar_rejeitaDocumentoDuplicadoEVazios() {
        assertTrue(cc.cadastrar("CLI-001", "Marta Silva", "842222222", "Beira"));
        assertFalse(cc.cadastrar("CLI-001", "Outro", "843333333", "Nampula"));
        assertFalse(cc.cadastrar("cli-001", "Outro", "843333333", "Nampula")); // sem distinção de caixa
        assertFalse(cc.cadastrar("", "Nome", "Contacto", "Local"));
        assertFalse(cc.cadastrar("CLI-002", "", "Contacto", "Local"));
        assertFalse(cc.cadastrar("CLI-002", "Nome", "", "Local"));
        assertFalse(cc.cadastrar("CLI-002", "Nome", "Contacto", "  "));
        assertEquals(1, cc.listar().size());
    }

    @Test
    public void actualizar_alteraOsCamposMasMantemADocumentacao() {
        assertTrue(cc.cadastrar("CLI-001", "Marta Silva", "842222222", "Beira"));

        assertTrue(cc.actualizar("CLI-001", "Marta Actualizada", "849999999", "Quelimane"));

        Cliente c = cc.buscarPorDocumento("CLI-001");
        assertEquals("Marta Actualizada", c.getNome());
        assertEquals("849999999", c.getContacto());
        assertEquals("Quelimane", c.getLocalizacao());
        assertEquals("CLI-001", c.getDocumentoCli());

        assertFalse(cc.actualizar("CLI-999", "Nome", "Contacto", "Local"));
        assertFalse(cc.actualizar("CLI-001", "", "Contacto", "Local"));
    }

    @Test
    public void remover_apagaApenasOAlvo() {
        assertTrue(cc.cadastrar("CLI-001", "Marta Silva", "842222222", "Beira"));
        assertTrue(cc.cadastrar("CLI-002", "João Bento", "843333333", "Nampula"));

        assertTrue(cc.remover("CLI-001"));
        assertNull(cc.buscarPorDocumento("CLI-001"));
        assertNotNull(cc.buscarPorDocumento("CLI-002"));
        assertFalse(cc.remover("CLI-001"));
    }

    @Test
    public void persistencia_dadosDisponiveisAposReiniciar() {
        assertTrue(cc.cadastrar("CLI-001", "Marta Silva", "842222222", "Beira"));

        ClienteController reiniciado = new ClienteController();
        assertEquals(1, reiniciado.listar().size());
        assertEquals("Marta Silva", reiniciado.buscarPorDocumento("CLI-001").getNome());
    }
}
