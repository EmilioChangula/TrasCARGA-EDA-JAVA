package controller;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.Carregamento;
import model.Cliente;
import model.Proprietario;
import model.Veiculo;
import util.FicheirosDeTeste;

/**
 * Requisitos 8, 9, 11 e 12: registo de carregamentos com validação da
 * capacidade máxima, consulta por proprietário, total por veículo e
 * persistência com relinkagem das relações.
 */
public class CarregamentoControllerTest {

    private static final LocalDate DATA = LocalDate.of(2026, 10, 1);

    private ProprietarioController pc;
    private VeiculoController vc;
    private ClienteController cc;
    private CarregamentoController car;
    private Cliente cliente;
    private Veiculo camiao; // capacidade 10 t

    @BeforeEach
    public void preparar() {
        FicheirosDeTeste.limpar();
        pc = new ProprietarioController();
        pc.cadastrar("Dono Um", "840000001", "BI-C1");
        vc = new VeiculoController();
        vc.cadastrarCamiao("CH-C1", "CAM-01", "Mercedes", "Actros", 10, pc.buscarPorDocumento("BI-C1"));
        camiao = vc.buscarPorMatricula("CAM-01");
        cc = new ClienteController();
        cc.cadastrar("CLI-001", "Marta Silva", "842222222", "Beira");
        cliente = cc.buscarPorDocumento("CLI-001");
        car = new CarregamentoController();
    }

    @Test
    public void registar_guardaTodosOsCamposDoRequisito8() {
        assertTrue(car.registar(cliente, camiao, 8, "Beira", "Nampula", DATA, 5000));

        assertEquals(1, car.listarTodos().size());
        Carregamento c = car.listarTodos().get(0);
        // cliente, veículo, quantidade, origem, destino, data e valor
        assertSame(cliente, c.getCliente());
        assertSame(camiao, c.getVeiculo());
        assertEquals("Marta Silva", c.getNomeCliente());
        assertEquals("CAM-01", c.getMatricula());
        assertEquals(8, c.getQuantidade());
        assertEquals("Beira", c.getOrigem());
        assertEquals("Nampula", c.getDestino());
        assertEquals(DATA, c.getData());
        assertEquals(5000, c.getValor());
        // o proprietário é obtido através do veículo
        assertEquals("Dono Um", c.getProprietario().getNome());
    }

    @Test
    public void validar_quantidadeNaoPodeUltrapassarACapacidade() {
        // requisito 9
        assertTrue(car.validar(camiao, 10));   // igual à capacidade é aceite
        assertTrue(car.validar(camiao, 0.5));
        assertFalse(car.validar(camiao, 10.1)); // excede a capacidade
        assertFalse(car.validar(camiao, 0));
        assertFalse(car.validar(camiao, -1));
        assertFalse(car.validar(null, 5));
    }

    @Test
    public void registar_rejeitaQuantidadeAcimaDaCapacidade() {
        assertFalse(car.registar(cliente, camiao, 10.5, "Beira", "Nampula", DATA, 5000));
        assertFalse(car.registar(cliente, camiao, 0, "Beira", "Nampula", DATA, 5000));
        assertFalse(car.registar(cliente, camiao, -2, "Beira", "Nampula", DATA, 5000));
        assertTrue(car.listarTodos().isEmpty());

        // no limite exacto é aceite
        assertTrue(car.registar(cliente, camiao, 10, "Beira", "Nampula", DATA, 5000));
        assertEquals(1, car.listarTodos().size());
    }

    @Test
    public void registar_rejeitaCamposObrigatorios() {
        assertFalse(car.registar(null, camiao, 5, "Beira", "Nampula", DATA, 100));      // sem cliente
        assertFalse(car.registar(cliente, null, 5, "Beira", "Nampula", DATA, 100));      // sem veículo
        assertFalse(car.registar(cliente, camiao, 5, "", "Nampula", DATA, 100));         // sem origem
        assertFalse(car.registar(cliente, camiao, 5, "Beira", " ", DATA, 100));          // sem destino
        assertFalse(car.registar(cliente, camiao, 5, "Beira", "Nampula", null, 100));    // sem data
        assertFalse(car.registar(cliente, camiao, 5, "Beira", "Nampula", DATA, -1));     // valor negativo
        assertTrue(car.listarTodos().isEmpty());
    }

    @Test
    public void listarPorProprietario_mostraApenasOsServicosDosSeusVeiculos() {
        // requisito 11: dois proprietários, um veículo cada
        pc.cadastrar("Dono Dois", "840000002", "BI-C2");
        vc.cadastrarCarrinha("CH-C2", "CAR-02", "Ford", "Transit", 2, pc.buscarPorDocumento("BI-C2"));
        Veiculo carrinha = vc.buscarPorMatricula("CAR-02");

        assertTrue(car.registar(cliente, camiao, 8, "Beira", "Nampula", DATA, 5000));
        assertTrue(car.registar(cliente, carrinha, 1, "Beira", "Tete", DATA, 700));

        assertEquals(2, car.listarTodos().size());

        var doDono1 = car.listarPorProprietario("BI-C1");
        assertEquals(1, doDono1.size());
        assertEquals("CAM-01", doDono1.get(0).getMatricula());
        assertEquals("Dono Um", doDono1.get(0).getProprietario().getNome());

        var doDono2 = car.listarPorProprietario("BI-C2");
        assertEquals(1, doDono2.size());
        assertEquals("CAR-02", doDono2.get(0).getMatricula());

        assertTrue(car.listarPorProprietario("BI-NAO-EXISTE").isEmpty());
    }

    @Test
    public void totalPorVeiculo_somaApenasOsCarregamentosDaqueleVeiculo() {
        // requisito 12
        vc.cadastrarCarrinha("CH-C2", "CAR-02", "Ford", "Transit", 2, pc.buscarPorDocumento("BI-C1"));
        Veiculo carrinha = vc.buscarPorMatricula("CAR-02");

        assertTrue(car.registar(cliente, camiao, 5, "Beira", "Nampula", DATA, 1000));
        assertTrue(car.registar(cliente, camiao, 5, "Tete", "Quelimane", DATA, 2500));
        assertTrue(car.registar(cliente, carrinha, 1, "Beira", "Tete", DATA, 300));

        assertEquals(3500, car.totalPorVeiculo("CAM-01"));
        assertEquals(300, car.totalPorVeiculo("CAR-02"));
        assertEquals(0, car.totalPorVeiculo("NAO-EXISTE"));
    }

    @Test
    public void ultimo_devolvePeekLastSemRemover() {
        assertNull(car.ultimo()); // estrutura vazia

        assertTrue(car.registar(cliente, camiao, 5, "Beira", "Nampula", DATA, 1000));
        Carregamento primeiro = car.listarTodos().get(0);
        assertSame(primeiro, car.ultimo());

        assertTrue(car.registar(cliente, camiao, 5, "Tete", "Tete", DATA, 2000));
        assertEquals(2000, car.ultimo().getValor());
        // peekLast não remove
        assertEquals(2, car.listarTodos().size());
    }

    @Test
    public void persistencia_relacoesPreservadasAposReiniciarERelinkar() {
        assertTrue(car.registar(cliente, camiao, 8, "Beira", "Nampula", DATA, 5000));

        // reinício: novo controller relê o ficheiro
        CarregamentoController reiniciado = new CarregamentoController();
        assertEquals(1, reiniciado.listarTodos().size());

        Carregamento c = reiniciado.listarTodos().get(0);
        assertEquals("CAM-01", c.getVeiculo().getMatricula());
        assertEquals("CLI-001", c.getCliente().getDocumentoCli());
        assertEquals("Dono Um", c.getProprietario().getNome());
        assertEquals(5000, c.getValor());

        // relinkar reconstrói as ligações para as instâncias canónicas
        VeiculoController vc2 = new VeiculoController();
        ClienteController cc2 = new ClienteController();
        ProprietarioController pc2 = new ProprietarioController();
        vc2.relinkar(pc2);
        reiniciado.relinkar(vc2, cc2);

        assertSame(vc2.buscarPorMatricula("CAM-01"), c.getVeiculo());
        assertSame(cc2.buscarPorDocumento("CLI-001"), c.getCliente());
        assertSame(pc2.buscarPorDocumento("BI-C1"), c.getProprietario());
    }

    @Test
    public void validar_semVeiculoOuQuantidadeInvalida_devolveFalso() {
        CarregamentoController vazio = new CarregamentoController();
        Proprietario dono = pc.buscarPorDocumento("BI-C1");
        assertNotNull(dono);
        assertFalse(vazio.validar(null, 5));
        assertFalse(vazio.validar(camiao, Double.NaN));
    }
}
