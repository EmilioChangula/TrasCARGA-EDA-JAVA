package controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.Proprietario;
import util.FicheirosDeTeste;

/**
 * Requisitos 1 e 4: cadastro e actualização de proprietários,
 * com impedimento de documentos duplicados e persistência em ficheiro.
 */
public class ProprietarioControllerTest {

    private ProprietarioController pc;

    @BeforeEach
    public void preparar() {
        FicheirosDeTeste.limpar();
        pc = new ProprietarioController();
    }

    @Test
    public void cadastrar_guardaComTodosOsCampos() {
        assertTrue(pc.cadastrar("Ana Bento", "840000001", "BI-001"));

        Proprietario p = pc.buscarPorDocumento("BI-001");
        assertNotNull(p);
        assertEquals("Ana Bento", p.getNome());
        assertEquals("840000001", p.getContacto());
        assertEquals("BI-001", p.getDocumentoID());
        assertEquals(1, pc.listar().size());
    }

    @Test
    public void cadastrar_rejeitaDocumentoDuplicado() {
        assertTrue(pc.cadastrar("Ana Bento", "840000001", "BI-001"));
        assertFalse(pc.cadastrar("Outro Nome", "840000002", "BI-001"));
        // duplicado sem distinção de maiúsculas/minúsculas
        assertFalse(pc.cadastrar("Outro Nome", "840000002", "bi-001"));
        assertEquals(1, pc.listar().size());
    }

    @Test
    public void cadastrar_rejeitaCamposObrigatoriosVazios() {
        assertFalse(pc.cadastrar("", "840000001", "BI-001"));
        assertFalse(pc.cadastrar("Ana", "", "BI-001"));
        assertFalse(pc.cadastrar("Ana", "840000001", " "));
        assertFalse(pc.cadastrar(null, null, null));
        assertTrue(pc.listar().isEmpty());
    }

    @Test
    public void actualizar_alteraNomeEContactoMasMantemAChave() {
        assertTrue(pc.cadastrar("Ana Bento", "840000001", "BI-001"));

        assertTrue(pc.actualizar("BI-001", "Ana Bento Actualizada", "841111111"));

        Proprietario p = pc.buscarPorDocumento("BI-001");
        assertEquals("Ana Bento Actualizada", p.getNome());
        assertEquals("841111111", p.getContacto());
        assertEquals("BI-001", p.getDocumentoID());
    }

    @Test
    public void actualizar_rejeitaDocumentoInexistenteEVazios() {
        assertTrue(pc.cadastrar("Ana Bento", "840000001", "BI-001"));

        assertFalse(pc.actualizar("BI-999", "Nome", "Contacto"));
        assertFalse(pc.actualizar("BI-001", "", "Contacto"));
        assertFalse(pc.actualizar("BI-001", "Nome", "  "));
    }

    @Test
    public void remover_apagaApenasOAlvo() {
        assertTrue(pc.cadastrar("Ana Bento", "840000001", "BI-001"));
        assertTrue(pc.cadastrar("Carlos Dias", "840000002", "BI-002"));

        assertTrue(pc.remover("BI-001"));
        assertNull(pc.buscarPorDocumento("BI-001"));
        assertNotNull(pc.buscarPorDocumento("BI-002"));
        assertEquals(1, pc.listar().size());

        assertFalse(pc.remover("BI-001")); // já removido
    }

    @Test
    public void persistencia_dadosDisponiveisAposReiniciar() {
        assertTrue(pc.cadastrar("Ana Bento", "840000001", "BI-001"));
        assertTrue(pc.cadastrar("Carlos Dias", "840000002", "BI-002"));

        // simula o reinício da aplicação: novo controller relê do ficheiro
        ProprietarioController reiniciado = new ProprietarioController();
        assertEquals(2, reiniciado.listar().size());
        assertEquals("Ana Bento", reiniciado.buscarPorDocumento("BI-001").getNome());
        assertEquals("Carlos Dias", reiniciado.buscarPorDocumento("BI-002").getNome());
    }
}
