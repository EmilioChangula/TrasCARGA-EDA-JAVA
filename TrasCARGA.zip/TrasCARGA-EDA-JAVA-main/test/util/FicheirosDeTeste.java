package util;

import java.io.File;

/**
 * Os testes correm com o directório de trabalho em target/ (ver pom.xml),
 * por isso os .dat criados ficam em target/ e nunca tocam nos dados reais
 * da aplicação, que vivem na raiz do projecto.
 */
public final class FicheirosDeTeste {

    public static final String[] PADRAO = {
        "proprietarios.dat",
        "veiculos.dat",
        "clientes.dat",
        "carregamentos.dat"
    };

    /** Apaga os ficheiros de dados para cada teste começar do zero. */
    public static void limpar() {
        apagar(PADRAO);
    }

    public static void apagar(String... nomes) {
        for (String nome : nomes) {
            File f = new File(nome);
            if (f.exists() && !f.delete()) {
                throw new IllegalStateException("Não foi possível apagar " + f.getAbsolutePath());
            }
        }
    }

    private FicheirosDeTeste() { }
}
