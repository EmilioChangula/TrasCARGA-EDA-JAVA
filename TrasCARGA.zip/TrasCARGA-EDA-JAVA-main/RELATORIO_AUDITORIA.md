# Relatório de Auditoria e Correcção — TrasCARGA (EDA / Java)

**Projecto:** `TrasCARGA-EDA-JAVA-main`
**Data:** 02/11/2026
**Objectivo:** Auditar o projecto contra o enunciado (TAD Deque + 12 requisitos funcionais),
corrigir os problemas encontrados, validar por compilação e testes, e entregar o relatório final.

---

## A. Resumo geral

O projecto é uma aplicação JavaFX de gestão de transportes (proprietários, veículos,
clientes, carregamentos) com persistência em ficheiros de objectos (serialização).

**Estado inicial:** o código-fonte estava completo e era conceptualmente correcto, mas o
projecto **não era executável nem testável** neste ambiente:

1. O build era do NetBeans/Ant (`build.xml`) com tarefas JavaFX obsoletas e `javac.classpath`
   vazio, e o platform `JDK_21` definido no `nbproject/project.properties` não existe → impossível compilar.
2. Não existia **nenhum teste** automatizado.
3. Defectos reais encontrados na revisão de código:
   - `fx/ProprietarioFx.java` lançava `NullPointerException` (`colNome` nulo) e tinha os
     rótulos `txtContacto`/`txtDocumento` trocados — ecrã morto (nunca aberto pelo menu).
   - Veículos: o UI já anunciava "chassi duplicado", mas **o código não verificava** o nº de chassi.
   - Falta de validação de campos vazios/nulos em proprietários, clientes e carregamentos
     (podia criar registos com `null` ou `""`).
   - `Camiao.getTipo()` devolvia `"Camiao"` (sem acento), inconsistente com a UI.

**Estado final:** build Maven funcional, 41 testes JUnit verdes, 12/12 ecrãs FXML a carregar,
aplicação a abrir a janela principal, atalho e script de execução corrigidos.

---

## B. Matriz de requisitos

| # | Requisito | Estado | Onde / evidência |
|---|-----------|--------|------------------|
| 1 | CRUD de proprietários | ✅ | `ProprietarioController.cadastrar/actualizar/listar/remover` + `ProprietarioFormFx`/`ProprietarioVerFx`; testes `ProprietarioControllerTest` (7) |
| 2 | Registo de veículos (camiões e carrinhas) | ✅ | `VeiculoController.cadastrarCamiao/cadastrarCarrinha`; `VeiculoFormFx` |
| 3 | Veículo obrigatoriamente associado a proprietário | ✅ | `cadastrarCamiao/Carrinha` exige `Proprietario` válido (`buscarPorDocumento`) |
| 4 | Actualização de registos | ✅ | `actualizar()` em Proprietario, Veiculo, Cliente |
| 5 | Listagens de veículos por capacidade **crescente** | ✅ | `VeiculoController.ordenadosPorCapacidade()` (inserção ordenada, sem `Collections.sort`) |
| 6 | Gestão de clientes | ✅ | `ClienteController.cadastrar/actualizar/listar/remover` |
| 7 | Registo de carregamentos (cliente, veículo, quantidade, origem, destino, data, valor) | ✅ | `CarregamentoController.registar(...)` com os 7 campos |
| 8 | Validação de capacidade máxima do veículo | ✅ | `CarregamentoController.validar()`: `quantidade > 0 && quantidade <= capacidade` |
| 9 | Listagem de carregamentos | ✅ | `listarTodos()` + `CarregamentoVerFx` |
| 10 | Consulta de transportes por proprietário | ✅ | `listarPorProprietario(documento)` |
| 11 | Total arrecadado por veículo | ✅ | `totalPorVeiculo(matricula)` |
| 12 | Persistência em ficheiros de objectos (incl. clientes e carregamentos) | ✅ | `persistencia/Ficheiro` (serialização) + `proprietarios.dat`, `veiculos.dat`, `clientes.dat`, `carregamentos.dat`; `Dados.relinkar()` religa objectos no arranque |

---

## C. Auditoria do TAD Deque

**Ficheiros:** `src/tad/Deque.java` (interface) e `src/tad/DequeArray.java` (implementação)

| Critério | Avaliação |
|----------|-----------|
| Interface + implementação correctas | ✅ `interface Deque<T> extends Iterable<T>` com as operações; `DequeArray<T> implements Deque<T>, Serializable` |
| Genéricos | ✅ totalmente genérico (`<T>`), sem `Object` exposto |
| Estrutura | ✅ array circular com `inicio`, `tamanho` e redimensionamento (`duplicar()`), complexidade **O(1)** amortizada em `addFirst/addLast/removeFirst/removeLast/peek*` e `O(1)` em `size/isEmpty/get` |
| Estrutura vazia | ✅ `remove*`/`peek*` devolvem `null` (não lançam exceção); `get()` lança `IndexOutOfBoundsException` com mensagem clara |
| Ordem / perda de elementos | ✅ preserva a ordem lógica em redimensionamentos e remoções (`duplicar()` reordena o array circular para `inicio=0`); sem perda de elementos — coberto por 9 testes |
| Integração real na aplicação | ✅ **é o tipo de dados de todos os controllers**: `DequeArray<Proprietario>`, `DequeArray<Veiculo>`, `DequeArray<Cliente>`, `DequeArray<Carregamento>` — sem substituição por `ArrayList`/`LinkedList`/`Queue` |
| Serialização | ✅ `Serializable` com `serialVersionUID` |
| Iterador | ✅ `iterator()` com `NoSuchElementException` correcta |

**Conclusão:** o TAD estava implementado de forma correcta e **não foi alterado** — apenas
foi testado (`test/tad/DequeArrayTest.java`, 9 testes).

---

## D. Lista de problemas encontrados

| # | Problema | Severidade |
|---|----------|------------|
| 1 | Build NetBeans/Ant inutilizável (Ant ausente, tarefas JavaFX obsoletas, `javac.classpath` vazio, `JDK_21` inexistente) | Crítica |
| 2 | Zero testes automatizados | Alta |
| 3 | `fx/ProprietarioFx.java` quebrado: `NullPointerException` (`colNome` nulo) + rótulos `txtContacto`/`txtDocumento` trocados + `xmlns` desactualizado | Alta (ecrã morto) |
| 4 | Nº de chassi não era validado como único apesar de a UI anunciar "chassi duplicado" | Média |
| 5 | Sem validação de campos vazios/nulos (proprietário, cliente, carregamento: origem/destino/data) | Média |
| 6 | `Camiao.getTipo()` devolvia `"Camiao"` em vez de `"Camião"` | Baixa |
| 7 | Atalho `TrasCARGA - Atalho.lnk` apontava para uma pasta inexistente | Média |
| 8 | `.gitignore` sem `target/` e `*.dat` | Baixa |

---

## E. Plano de correcção (executado)

1. **Build Maven** — criado `pom.xml` (OpenJFX 25.0.5, `maven.compiler.release=21`,
   `sourceDirectory=src`, `testSourceDirectory=test`, main class `trascarga.TrasCARGA`,
   surefire com `workingDirectory=target` para os testes nunca tocarem nos `.dat` reais).
   O `build.xml` do NetBeans foi **preservado** (mantém a estrutura original).
2. **Ecrã Proprietário reparado** — `fx/ProprietarioFx.java` defensivo (nulos protegidos),
   rótulos corrigidos em `view/Proprietario.fxml`, `xmlns` actualizado para 11.0.1.
3. **Validações** — chassi único em `cadastrarCamiao`, `cadastrarCarrinha` e `actualizar`;
   guardas de campos vazios/nulos em `ProprietarioController`, `ClienteController`,
   `VeiculoController` e `CarregamentoController.registar`.
4. **`Camiao.getTipo()`** → `"Camião"`.
5. **Testes JUnit 5** em `test/` (7 ficheiros, 41 testes): Deque, Ficheiro/persistência e os
   4 controllers (inclui capacidade máxima, ordenação crescente, CRUD, chassi duplicado,
   consulta por proprietário e total por veículo).
6. **Ferramenta de verificação FXML** — `src/fx/TesteCarga.java` carrega os 12 ecrãs na
   thread JavaFX e reporta falhas (utilitário mantido no projecto).
7. **Execução** — `run.bat` (compila e inicia via Maven) e `TrasCARGA - Atalho.lnk`
   repontado para o `run.bat` com o directório de trabalho correcto.
8. **`.gitignore`** — adicionados `target/` e `*.dat`.

---

## Validações executadas

| Validação | Resultado |
|-----------|-----------|
| `mvn -B clean compile` | ✅ BUILD SUCCESS (29 fontes, só avisos de *unchecked*) |
| `mvn -B clean test` | ✅ **41 testes, 0 falhas** (`DequeArrayTest` 9, `FicheiroTest` 2, `ProprietarioControllerTest` 7, `VeiculoControllerTest` 9, `ClienteControllerTest` 5, `CarregamentoControllerTest` 9) |
| Smoke test FXML (`fx.TesteCarga`) | ✅ **12/12 ecrãs carregados** — `RESULTADO: TODAS AS TELAS CARREGARAM` |
| Arranque real (`mvn javafx:run`) | ✅ janela **"TransCarga Moçambique"** aberta, sem excepções |
| Integridade dos dados | ✅ nenhum `.dat` real alterado pelos testes (directório de trabalho dos testes = `target/`) |

## Limitações conhecidas

- O build **NetBeans/Ant original foi mantido** mas continua não funcional neste ambiente
  (o projecto passa a ser construído com Maven — `mvn compile` / `run.bat`).
- `src/fx/TesteCarga.java` foi mantido como utilitário de verificação rápida dos FXML
  (não faz parte do fluxo normal da aplicação).
- A aplicação persiste os `.dat` no directório de trabalho (raiz do projecto ao correr
  via `run.bat`).
- Os dados não têm interface de "apagar tudo"; a remoção de veículos/clientes com
  carregamentos associados é bloqueada por desenho (`temVeiculo`/`temCliente`).
