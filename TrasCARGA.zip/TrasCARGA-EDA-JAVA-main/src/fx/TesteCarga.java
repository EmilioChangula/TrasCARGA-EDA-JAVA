package fx;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;

/**
 * Teste temporário: carrega todas as telas FXML para validar
 * fx:id, onAction e controllers. Não faz parte da aplicação.
 */
public class TesteCarga {

    private static final String[] TELAS = {
        "/view/Principal.fxml",
        "/view/Dashboard.fxml",
        "/view/ProprietarioForm.fxml",
        "/view/ProprietarioVer.fxml",
        "/view/Proprietario.fxml",
        "/view/VeiculoForm.fxml",
        "/view/VeiculoVer.fxml",
        "/view/ClienteForm.fxml",
        "/view/ClienteVer.fxml",
        "/view/CarregamentoForm.fxml",
        "/view/CarregamentoVer.fxml",
        "/view/Consultas.fxml"
    };

    public static void main(String[] args) throws Exception {
        CountDownLatch fim = new CountDownLatch(1);
        final Throwable[] erro = {null};

        Platform.startup(() -> {
            int falhas = 0;
            try {
                for (String tela : TELAS) {
                    try {
                        FXMLLoader loader = new FXMLLoader(TesteCarga.class.getResource(tela));
                        loader.load();
                        Object ctrl = loader.getController();
                        System.out.println("OK   " + tela + "  ->  "
                                + (ctrl == null ? "(sem controller)" : ctrl.getClass().getName()));
                    } catch (Throwable t) {
                        falhas++;
                        System.out.println("FALHA " + tela + "  ->  " + t);
                        Throwable causa = t.getCause();
                        while (causa != null) {
                            System.out.println("        causa: " + causa);
                            causa = causa.getCause();
                        }
                    }
                }
                if (falhas == 0) {
                    System.out.println("RESULTADO: TODAS AS TELAS CARREGARAM");
                } else {
                    System.out.println("RESULTADO: " + falhas + " TELA(S) COM FALHA");
                    erro[0] = new RuntimeException(falhas + " falha(s)");
                }
            } catch (Throwable t) {
                erro[0] = t;
            } finally {
                fim.countDown();
            }
        });

        if (!fim.await(90, TimeUnit.SECONDS)) {
            System.out.println("RESULTADO: TIMEOUT");
            System.exit(2);
        }
        if (erro[0] != null) {
            System.out.println("RESULTADO: FALHA");
            erro[0].printStackTrace();
            System.exit(1);
        }
        Platform.exit();
        System.exit(0);
    }
}
