@echo off
rem =========================================================
rem  TrasCARGA - Mostrar os passos de execucao
rem  Compila o projeto e inicia a aplicacao JavaFX.
rem  Requer: JDK 21+ e Maven instalados (variavel PATH).
rem =========================================================
cd /d "%~dp0"

echo A compilar o projeto...
call mvn -q -B compile
if errorlevel 1 (
    echo.
    echo ERRO: falha na compilacao. Verifique o Maven e o JDK.
    pause
    exit /b 1
)

echo A iniciar a aplicacao...
call mvn -q -B javafx:run
if errorlevel 1 (
    echo.
    echo ERRO: falha ao iniciar a aplicacao.
    pause
    exit /b 1
)
